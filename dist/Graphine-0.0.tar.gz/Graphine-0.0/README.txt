If you have this, you probably already know what to do- but in case you don't:

Graphine can be installed via sudo ./setup.py install

It can be imported via:

import graph

and its documentation is available at Graphine.org.

This is an open source project. Please respect the spirit in which it was
developed- and read the license if in doubt.

--Geremy Condra (debatem1 at gmail dot com)
