#! /usr/bin/env python3.0

from distutils.core import setup

setup(name='Graphine',
      version='0.0',
      description='Pythonic Graph Library',
      author='Geremy Condra',
      author_email='CTO@OpenMigration.Net',
      url='http://www.graphine.org',
      packages=['graph']
     )

